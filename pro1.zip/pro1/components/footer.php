<footer class="footer">

   &copy; created by <?= date('Y'); ?> miss. vaishnavi <span></span> | all rights reserved!

</footer>